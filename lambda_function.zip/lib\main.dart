import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
 
void main() {
  runApp(StudyShareApp());
}
 
class StudyShareApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'StudyShare',
      theme: ThemeData(primarySwatch: Colors.pink),
      initialRoute: '/',
      routes: {
        '/': (context) => SignInPage(),
        '/signup': (context) => SignUpPage(),
        '/forgot': (context) => ForgotPasswordPage(),
        '/school': (context) => SchoolSelectionPage(),
        '/program': (context) => ProgramSelectionPage(),
        '/year': (context) => YearSelectionPage(),
        '/main': (context) => MainPage(),
      },
    );
  }
}
 
class SignInPage extends StatelessWidget {
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
 
  void signIn(BuildContext context) {
    if (emailController.text.isNotEmpty && passwordController.text.isNotEmpty) {
      Navigator.pushReplacementNamed(context, '/school');
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Vnesi podatke')));
    }
  }
 
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Prijava')),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(controller: emailController, decoration: InputDecoration(labelText: 'Gmail')),
            TextField(controller: passwordController, decoration: InputDecoration(labelText: 'Geslo'), obscureText: true),
            ElevatedButton(onPressed: () => signIn(context), child: Text('Prijavi se')),
            TextButton(onPressed: () => Navigator.pushNamed(context, '/signup'), child: Text('Ustvari račun')),
            TextButton(onPressed: () => Navigator.pushNamed(context, '/forgot'), child: Text('Pozabljeno geslo?')),
          ],
        ),
      ),
    );
  }
}
 
class SignUpPage extends StatefulWidget {
  @override
  _SignUpPageState createState() => _SignUpPageState();
}
 
class _SignUpPageState extends State<SignUpPage> {
  final nameController = TextEditingController();
  final emailController = TextEditingController();
  final schoolController = TextEditingController();
  final programController = TextEditingController();
  final yearController = TextEditingController();
 
  void signUp(BuildContext context) async {
    if (nameController.text.isNotEmpty &&
        emailController.text.isNotEmpty &&
        schoolController.text.isNotEmpty &&
        programController.text.isNotEmpty &&
        yearController.text.isNotEmpty) {
      await Future.delayed(Duration(seconds: 1));
      if (!mounted) return;
      Navigator.pushReplacementNamed(context, '/school');
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Izpolni vsa polja')));
    }
  }
 
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Registracija')),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(controller: nameController, decoration: InputDecoration(labelText: 'Ime')),
            TextField(controller: emailController, decoration: InputDecoration(labelText: 'Email')),
            TextField(controller: schoolController, decoration: InputDecoration(labelText: 'Šola')),
            TextField(controller: programController, decoration: InputDecoration(labelText: 'Program')),
            TextField(controller: yearController, decoration: InputDecoration(labelText: 'Letnik')),
            ElevatedButton(onPressed: () => signUp(context), child: Text('Registriraj se')),
          ],
        ),
      ),
    );
  }
}
 
class ForgotPasswordPage extends StatelessWidget {
  final emailController = TextEditingController();
 
  void resetPassword(BuildContext context) {
    if (emailController.text.isNotEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Povezava za ponastavitev gesla poslana.')));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Vnesi email')));
    }
  }
 
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Pozabljeno geslo')),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(controller: emailController, decoration: InputDecoration(labelText: 'Vnesi Gmail')),
            ElevatedButton(onPressed: () => resetPassword(context), child: Text('Pošlji povezavo')),
          ],
        ),
      ),
    );
  }
}
 
class SchoolSelectionPage extends StatelessWidget {
  final schools = ['Gimnazija Maribor', 'Srednja elektro šola', 'Višja šola L.I.V.E.'];
 
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Izberi šolo')),
      body: ListView.builder(
        itemCount: schools.length,
        itemBuilder: (context, index) => ListTile(
          title: Text(schools[index]),
          onTap: () => Navigator.pushNamed(context, '/program'),
        ),
      ),
    );
  }
}
 
class ProgramSelectionPage extends StatelessWidget {
  final programs = ['Računalništvo in informatika', 'Ekonomist', 'Varstvo okolja', 'Logistično inženirstvo'];
 
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Izberi program')),
      body: ListView.builder(
        itemCount: programs.length,
        itemBuilder: (context, index) => ListTile(
          title: Text(programs[index]),
          onTap: () => Navigator.pushNamed(context, '/year'),
        ),
      ),
    );
  }
}
 
class YearSelectionPage extends StatelessWidget {
  final years = ['1. letnik', '2. letnik'];
 
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Izberi letnik')),
      body: ListView.builder(
        itemCount: years.length,
        itemBuilder: (context, index) => ListTile(
          title: Text(years[index]),
          onTap: () => Navigator.pushNamed(context, '/main'),
        ),
      ),
    );
  }
}
 
class MainPage extends StatefulWidget {
  @override
  _MainPageState createState() => _MainPageState();
}
 
class _MainPageState extends State<MainPage> {
  final subjects = ['Matematika', 'Programiranje', 'Fizika', 'Zgodovina'];
  String query = '';
  double? temperature;
 
  @override
  void initState() {
    super.initState();
    fetchTemperature();
  }
 
  Future<void> fetchTemperature() async {
    final apiKey = 'cbc5ce738d1dba734bcc43106e168d77';
    final city = 'Ljubljana';
    final url = 'https://api.openweathermap.org/data/2.5/weather?q=$city&units=metric&appid=$apiKey';
 
    try {
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        setState(() {
          temperature = data['main']['temp'];
        });
      } else {
        print('Napaka: ${response.statusCode}');
      }
    } catch (e) {
      print('Napaka: $e');
    }
  }
 
  @override
  Widget build(BuildContext context) {
    final filtered = subjects.where((s) => s.toLowerCase().contains(query.toLowerCase())).toList();
 
    return Scaffold(
      appBar: AppBar(title: Text('Predmeti')),
      body: Column(
        children: [
          if (temperature != null)
            Padding(
              padding: EdgeInsets.all(12),
              child: Text(
                '🌡️ Trenutna temperatura v Ljubljani: ${temperature!.toStringAsFixed(1)}°C',
                style: TextStyle(fontSize: 16),
              ),
            ),
          Padding(
            padding: EdgeInsets.all(12),
            child: TextField(
              decoration: InputDecoration(labelText: 'Išči predmet'),
              onChanged: (val) => setState(() => query = val),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: filtered.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(filtered[index]),
                  onTap: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Odprl bi zapiske za ${filtered[index]}')),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
 
 