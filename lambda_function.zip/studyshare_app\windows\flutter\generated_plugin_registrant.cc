//
//  Generated file. Do not edit.
//

// clang-format off

#include "generated_plugin_registrant.h"


void RegisterPlugins(flutter::PluginRegistry* registry) {
}
