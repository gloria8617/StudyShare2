import 'dart:convert';
import 'package:http/http.dart' as http;

const String apiUrl = 'https://nl5ekmyl0h.execute-api.eu-north-1.amazonaws.com/poskus';
const String apiKey = 'm7KR0SCFnW1ybUdFJ4Sg08UGHaWwcVZh3Y64kBrU'; // zamenjaj z dejanskim ključem

Future<List<String>> pridobiPredmete() async {
  final response = await http.get(
    Uri.parse(apiUrl),
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
    },
  );

  if (response.statusCode == 200) {
    final List<dynamic> jsonList = jsonDecode(response.body);
    return jsonList.map((item) => item['Ime_predmeta'].toString()).toList();
  } else {
    print('Napaka pri pridobivanju: ${response.statusCode}');
    return [];
  }
}
